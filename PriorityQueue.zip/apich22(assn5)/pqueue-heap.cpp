/*************************************************************
 * File: pqueue-heap.cpp
 *
 * Implementation file for the HeapPriorityQueue
 * class.
 */
 
#include "pqueue-heap.h"
#include "error.h"
#include <iostream>

const int initialLength = 1000;

HeapPriorityQueue::HeapPriorityQueue() {
	totalLengthReserved = initialLength;
	arr = new string[totalLengthReserved];
	currLength = 0;
}

HeapPriorityQueue::~HeapPriorityQueue() {
	delete[] arr;
}

int HeapPriorityQueue::size() {
	return currLength;
}

bool HeapPriorityQueue::isEmpty() {	
	return size() == 0;
}

void HeapPriorityQueue::enqueue(string value) {
	currLength++;
	if (currLength == totalLengthReserved) {
		expand();
	}
	if (currLength == 1) {
		arr[currLength] = value;
		return;
	}

	arr[currLength] = value;
	int currNode = currLength;
	int  parent = currNode / 2;
	while (parent >= 1 && arr[currNode] < arr[parent]) {
		swap(currNode, parent);
		currNode = parent;
		parent = currNode / 2;
	}

}

string HeapPriorityQueue::peek() {
	if (isEmpty()) {
		error("Queue is empty!");
	}
	return arr[1];
}

string HeapPriorityQueue::dequeueMin() {

	string minVal = peek();
	if (currLength == 1) {
		currLength = 0;
		return minVal;
	}
	swap(1, currLength);
	currLength--;

	int currNode = 1;
	int leftChild = currNode * 2;
	int rightChild = currNode * 2 + 1;
	int smallestChild = findSmallestChild(currNode, leftChild, rightChild);

	while (currLength >= smallestChild) {

		if (smallestChild != currNode) {
			swap(smallestChild, currNode);
			currNode = smallestChild;
			leftChild = currNode * 2;
			rightChild = currNode * 2 + 1;
			if (leftChild > currLength) break;
			smallestChild = findSmallestChild(currNode, leftChild, rightChild);
		}
		else {
			break;
		}

	}
	return minVal;
}

void HeapPriorityQueue::expand() {
	totalLengthReserved *= 2;
	string* copy = new string[totalLengthReserved];
	for (int i = 0; i < currLength; i++) {
		copy[i] = arr[i];
	}
	delete[] arr;
	arr = copy;
}

void HeapPriorityQueue::swap(int child, int parent) {
	string tmp = arr[child];
	arr[child] = arr[parent]; 
	arr[parent] = tmp;
}

int HeapPriorityQueue::findSmallestChild(int currNode, int left, int right) {
	int smallest = currNode;
	if (right > currLength) {
		if (arr[left] < arr[currNode]) {
			return left;
		}
		else {
			return currNode;
		}
	}
	if (arr[left] >= arr[right] && arr[right] <= arr[currNode]) {
		smallest = right;
	}
	else if(arr[right] > arr[left] && arr[left] < arr[currNode]) {
		smallest = left;
	}
	return smallest;
}



