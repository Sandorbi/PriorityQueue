/*************************************************************
 * File: pqueue-linkedlist.cpp
 *
 * Implementation file for the LinkedListPriorityQueue
 * class.
 */
 
#include "pqueue-linkedlist.h"
#include "error.h"
#include <iostream>

LinkedListPriorityQueue::LinkedListPriorityQueue() {
	length = 0;
	start = NULL;
}

LinkedListPriorityQueue::~LinkedListPriorityQueue() {
	// TODO: Fill this in!
	Node* curr;
	while (start != NULL) {
		curr = start;
		start = start->next;
		delete curr;
	}
}

int LinkedListPriorityQueue::size() {
	return length;
}

bool LinkedListPriorityQueue::isEmpty() {	
	return length == 0;
}

void LinkedListPriorityQueue::enqueue(string value) {
	length++;
	Node* newNode = new Node;
	newNode->str = value;
	newNode->next = NULL;
	if (start == NULL) {
		start = newNode;
		return;
	}

	if (value < start->str) {
		newNode->next = start;
		start = newNode;
		return;
	}

	Node* curr = start;
	Node* prev = NULL;

	while (curr != NULL && curr->str <= value) {
		prev = curr;
		curr = curr->next;
	}
	prev->next = newNode;
	newNode->next = curr;
}

string LinkedListPriorityQueue::peek() {
	if (length == 0) {
		error("Queue is empty!");
	}
	else {
		return start->str;
	}
}

string LinkedListPriorityQueue::dequeueMin() {
	string val = peek();
	Node* temp = start;
	start = start->next;
	delete temp;
	length--;
	return val;
}

