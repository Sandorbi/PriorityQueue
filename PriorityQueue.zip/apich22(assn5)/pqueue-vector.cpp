/*************************************************************
 * File: pqueue-vector.cpp
 *
 * Implementation file for the VectorPriorityQueue
 * class.
 */
 
#include "pqueue-vector.h"
#include "error.h"

VectorPriorityQueue::VectorPriorityQueue() {
}

VectorPriorityQueue::~VectorPriorityQueue() {
}

int VectorPriorityQueue::size() {
	return queue.size();
}

bool VectorPriorityQueue::isEmpty() {
	return queue.size() == 0;
}

void VectorPriorityQueue::enqueue(string value) {

	for (int i = 0; i < queue.size(); i++) {
		if (queue.get(i) > value) {
			queue.insert(i, value);
			return;
		}
	}
	queue.add(value);
}

string VectorPriorityQueue::peek() {
	if (queue.isEmpty()) {
		error("Queue is empty!");
	}
	else {
		return queue.get(0);
	}
}

string VectorPriorityQueue::dequeueMin() {
	string min = peek();
	queue.remove(0);
	return min;
}

