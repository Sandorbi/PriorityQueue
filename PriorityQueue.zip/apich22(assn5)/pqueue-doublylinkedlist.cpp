/*************************************************************
 * File: pqueue-doublylinkedlist.cpp
 *
 * Implementation file for the DoublyLinkedListPriorityQueue
 * class.
 */
 
#include "pqueue-doublylinkedlist.h"
#include "error.h"

DoublyLinkedListPriorityQueue::DoublyLinkedListPriorityQueue() {
	length = 0;
	start = NULL;
}

DoublyLinkedListPriorityQueue::~DoublyLinkedListPriorityQueue() {
	Node* curr;
	while (start != NULL) {
		curr = start;
		start = start->next;
		delete curr;
	}
}

int DoublyLinkedListPriorityQueue::size() {
	return length;
}

bool DoublyLinkedListPriorityQueue::isEmpty() {	
	return length == 0;
}

void DoublyLinkedListPriorityQueue::enqueue(string value) {
	length++;
	Node* newNode = new Node;
	newNode->str = value;
	newNode->next = NULL;
	newNode->prev = NULL;
	if (start == NULL) {
		start = newNode;
		return;
	}
	start->prev = newNode;
	newNode->next = start;
	start = newNode;	
}

string DoublyLinkedListPriorityQueue::peek() {
	if (isEmpty()) {
		error("Queue is empty!");
	}
	else {
		Node* min = start;
		Node* curr = start->next;
		while (curr != NULL) {
			if (curr->str < min->str) {
				min = curr;
			}
			curr = curr->next;
		}
		return min->str;
	}
}

string DoublyLinkedListPriorityQueue::dequeueMin() {
	if (isEmpty()) {
		error("Queue is empty!");
	}
	else {
		Node* min = start;
		string minVal = min->str;
		Node* curr = start->next;
		while (curr != NULL) {
			if (curr->str < minVal) {
				min = curr;
				minVal = min->str;
			}
			curr = curr->next;
		}
		if (min == start) {
			start = start->next;
		}
		else if (min->next == NULL) {
			min->prev->next = min->next;
		}
		else {
			min->prev->next = min->next;
			min->next->prev = min->prev;
		}
		length--;
		delete min;
		return minVal;
	}
}

